# Bank-Customer-Analysis-Using-Excel
This project explores a comprehensive Bank Customer Dataset containing detailed information about account holders. The dataset includes key attributes such as unique Customer IDs, First and Surnames, Age, Gender, and Age Status categories. 
